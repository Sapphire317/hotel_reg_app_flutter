import 'package:flutter/material.dart';


const kShrinePink50 = const Color(0XFFFEEAE6);
const kShrinePink100 = const Color(0XFFFEDBD0);
const kShrinePink300 = const Color(0XFFFBBBAC);
const kShrinePink400 = const Color(0XFFEAA4A4);

const kShrineBrown900 = const Color(0XFF442B2D);

const kShrineErrorRed = const Color(0XFFC50328);

const kShrineSurfaceWhite = const Color(0XFFFFFBFA);
const kShrineBackgroundWhite = Colors.white;